package mbf;

import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class ConexionBase {
        Connection conectar =null;
        Statement sentencia =null;
        ResultSet resultado = null;
public ConexionBase(){
    try{
        String rutafile = "C:\\Users\\kevin\\OneDrive\\Documentos\\mb\\JavaApplication2\\mb.accdb";
        String Url = "jdbc:ucanaccess://" + rutafile;
        conectar=DriverManager.getConnection(Url);
        sentencia=conectar.createStatement();
        JOptionPane.showMessageDialog(null,"Conectado a la Base de datos");
        
    }catch (Exception e){
        JOptionPane.showMessageDialog(null,"Error al conectar ala base de datos" + e);
        System.exit(0);
    }

}
public Connection getConnection(){
    return conectar;
}
}
